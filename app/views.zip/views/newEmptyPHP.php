http://localhost/l-arcdox/public/
http://localhost/l-arcdox/public/user/register
http://localhost/l-arcdox/public/admin/dashboard
[post]http://localhost/l-arcdox/public/admin/training/add
http://localhost/l-arcdox/public/admin/training/manage
http://localhost/l-arcdox/public/admin/training/edit/12
http://localhost/l-arcdox/public/admin/courses
http://localhost/l-arcdox/public/admin/courses/add
[post]http://localhost/l-arcdox/public/admin/courses/add

