<!doctype html>
<html>
 <head>
  <link href="<?php echo URL::to('resources/css/bootstrap.min.css'); ?>" rel="stylesheet">
             <link href="<?php echo URL::to('resources/css/bootstrap-theme.min.css'); ?>" rel="stylesheet">
            <link href="<?php echo URL::to('resources/style.css'); ?>" rel="stylesheet">
            <script src="<?php echo URL::to('resources/jquery.min.js');?>"></script> 
            <script src="<?php echo URL::to('resources/js/bootstrap.min.js'); ?>"></script>  
            <script src="<?php echo URL::to('resources/newjavascript.js');?>"></script> 
 @yield('content')

 
</div>

</body>
</html>
  