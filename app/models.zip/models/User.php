<?php

use Illuminate\Auth\UserTrait;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;

class User extends Eloquent implements UserInterface, RemindableInterface {
    
	use UserTrait, RemindableTrait;

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
        protected $fillable = array('email','role','password','firstname','surname','company_id','profession','created_at','updated_at');
	protected $table = 'users';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
	protected $hidden = array('password', 'remember_token');
        
        function insert_user_detail($firstname,$surname,$email,$profession,$companyid,$pass,$new_company_name)
        {     
               $password = Hash::make($pass);
                if($new_company_name != '') 
                {
                $companyid=DB::table('companydetails')->insertGetId(array('company_name'=> $new_company_name));
                }
                $user=DB::table('users')->insert(array('firstname'=>$firstname,'surname'=>$surname,'email'=>$email,'profession'=>$profession,'company_id'=>$companyid,'password'=>$password,'role'=>2));
                return($user);
        }
        function update_user_detail($firstname,$surname,$workemail,$email,$profession,$linkedin,$twitter,$facebook,$homeaddress1,$homeaddress2,$city,$county,$country,$telephone,$mobile)
        { 
         $id=Session::get('id'); 
         $affectedrows = User::where('id', '=', $id)->update(array('firstname' =>$firstname,'surname'=>$surname,'w_email'=>$workemail,'email'=>$email,'profession'=>$profession,'linkedin'=>$linkedin,'twitter'=>$twitter,'facebook'=>$facebook,'haddress1'=>$homeaddress1,'haddress2'=>$homeaddress2,'city'=>$city,'postcode'=>$county,'country'=>$country,'telephone'=>$telephone,'mobile'=>$mobile));
          if($affectedrows)
          {
              echo 'data inserted'; 
          }
          else
          {
              echo 'fail in updation';
          }
        }

}
